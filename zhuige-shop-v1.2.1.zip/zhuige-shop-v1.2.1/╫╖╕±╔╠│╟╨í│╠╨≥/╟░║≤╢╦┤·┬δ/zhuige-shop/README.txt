=== ZhuiGe Shop Mini Program ===
Contributors: zhuige
Donate link: https://www.zhuige.com/
Tags: 追格,商城,小程序,微信
Requires at least: 5.6
Tested up to: 5.9
Stable tag: 1.0.0
Requires PHP: 7.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

追格商城小程序是基于WordPress和uni-app开发的购物商城系统，所有源代码无加密、无后门，简单配置即可发布！

== Description ==

## 功能与特点

就是一个简单的商城小程序

微信：**jianbing2011**（加微信，进微信群交流）


== Installation ==

1. 把zhuige-shop文件夹上传到/wp-content/plugins/目录下

2. 在后台插件列表中启用"追格商城小程序"

3. 设置微信小程序的appid，及其他配置信息


== Frequently Asked Questions ==

= 前端代码从哪里获取 =

官网下载：[www.zhuige.com](https://www.zhuige.com/product/sc.html)

github下载：https://github.com/zhuige-com/zhuige_shop


== Screenshots ==

1. screenshot-1.png
2. screenshot-2.png

== Changelog ==

= 1.0 =
* 第一版

== Upgrade Notice ==
* 暂无