module.exports = {
	//你的域名
	JQ_DOMAIN: 'mall.zhuige.com',
};
