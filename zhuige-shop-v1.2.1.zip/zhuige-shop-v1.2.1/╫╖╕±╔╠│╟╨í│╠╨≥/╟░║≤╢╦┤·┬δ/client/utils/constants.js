module.exports = {
	//用户信息
	ZHUIGE_USER_KEY: 'zhuige_user_key',

	//搜索词 缓存个数
	ZHUIGE_SEARCH_MAX_COUNT: 20,
	
	//搜索词 缓存 key
	ZHUIGE_SEARCH_KEY: 'zhuige_search',
};
